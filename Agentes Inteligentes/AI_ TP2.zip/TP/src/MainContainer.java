import Auxiliar.Consts;
import jade.core.Runtime;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;

public class MainContainer {

    Runtime rt;
    ContainerController container;

    public ContainerController initContainerInPlatform(String host, String port, String containerName) {
        // Get the JADE runtime interface (singleton)
        this.rt = Runtime.instance();

        // Create a Profile, where the launch arguments are stored
        Profile profile = new ProfileImpl();
        profile.setParameter(Profile.CONTAINER_NAME, containerName);
        profile.setParameter(Profile.MAIN_HOST, host);
        profile.setParameter(Profile.MAIN_PORT, port);
        // create a non-main agent container
        ContainerController container = rt.createAgentContainer(profile);
        return container;
    }

    public void initMainContainerInPlatform(String host, String port, String containerName) {

        // Get the JADE runtime interface (singleton)
        this.rt = Runtime.instance();

        // Create a Profile, where the launch arguments are stored
        Profile prof = new ProfileImpl();
        prof.setParameter(Profile.CONTAINER_NAME, containerName);
        prof.setParameter(Profile.MAIN_HOST, host);
        prof.setParameter(Profile.MAIN_PORT, port);
        prof.setParameter(Profile.MAIN, "true");
        prof.setParameter(Profile.GUI, "true");

        // create a main agent container
        this.container = rt.createMainContainer(prof);
        rt.setCloseVM(true);
    }

    public static void main(String[] args) {
        MainContainer a = new MainContainer();

        try {
            Thread.sleep(1000);

            a.initMainContainerInPlatform("localhost", "9090", "MainContainer");

            Object[] args_input = new Object[] {"Container1", "Container2"};

            ContainerController newcontainer0 = a.initContainerInPlatform("localhost", "9886", "Container0");
            ContainerController newcontainer1 = a.initContainerInPlatform("localhost", "9887",
                    args_input[0].toString());
            ContainerController newcontainer2 = a.initContainerInPlatform("localhost", "9888",
                    args_input[1].toString());


            AgentController interfasse = newcontainer0.createNewAgent("Interface", "Agents.AgenteInterface", new Object[] {});

            interfasse.start();

            AgentController aguas_santas            = newcontainer1.createNewAgent("aguas_santas",              "Agents.AgenteEstacao", new Object[] {});
            AgentController ajude                   = newcontainer1.createNewAgent("ajude",                     "Agents.AgenteEstacao", new Object[] {});
            AgentController brunhais                = newcontainer1.createNewAgent("brunhais",                  "Agents.AgenteEstacao", new Object[] {});
            AgentController calvos                  = newcontainer1.createNewAgent("calvos",                    "Agents.AgenteEstacao", new Object[] {});
            AgentController campos                  = newcontainer1.createNewAgent("campos",                    "Agents.AgenteEstacao", new Object[] {});
            AgentController covelas                 = newcontainer1.createNewAgent("covelas",                   "Agents.AgenteEstacao", new Object[] {});
            AgentController esperanca               = newcontainer1.createNewAgent("esperanca",                 "Agents.AgenteEstacao", new Object[] {});
            AgentController ferreiros               = newcontainer1.createNewAgent("ferreiros",                 "Agents.AgenteEstacao", new Object[] {});
            AgentController fonte_arcada            = newcontainer1.createNewAgent("fonte_arcada",              "Agents.AgenteEstacao", new Object[] {});
            AgentController frades                  = newcontainer1.createNewAgent("frades",                    "Agents.AgenteEstacao", new Object[] {});
            AgentController friande                 = newcontainer1.createNewAgent("friande",                   "Agents.AgenteEstacao", new Object[] {});
            AgentController galegos                 = newcontainer1.createNewAgent("galegos",                   "Agents.AgenteEstacao", new Object[] {});
            AgentController garfe                   = newcontainer1.createNewAgent("garfe",                     "Agents.AgenteEstacao", new Object[] {});
            AgentController geraz_do_minho          = newcontainer1.createNewAgent("geraz_do_minho",            "Agents.AgenteEstacao", new Object[] {});
            AgentController lanhoso                 = newcontainer1.createNewAgent("lanhoso",                   "Agents.AgenteEstacao", new Object[] {});
            AgentController louredo                 = newcontainer1.createNewAgent("louredo",                   "Agents.AgenteEstacao", new Object[] {});
            AgentController monsul                  = newcontainer1.createNewAgent("monsul",                    "Agents.AgenteEstacao", new Object[] {});
            AgentController moure                   = newcontainer1.createNewAgent("moure",                     "Agents.AgenteEstacao", new Object[] {});
            AgentController nossa_senhora_do_amparo = newcontainer1.createNewAgent("nossa_senhora_do_amparo",   "Agents.AgenteEstacao", new Object[] {});
            AgentController oliveira                = newcontainer1.createNewAgent("oliveira",                  "Agents.AgenteEstacao", new Object[] {});
            AgentController rendufinho              = newcontainer1.createNewAgent("rendufinho",                "Agents.AgenteEstacao", new Object[] {});
            AgentController santo_emiliao           = newcontainer1.createNewAgent("santo_emiliao",             "Agents.AgenteEstacao", new Object[] {});
            AgentController sao_joao_de_rei         = newcontainer1.createNewAgent("sao_joao_de_rei",           "Agents.AgenteEstacao", new Object[] {});
            AgentController serzedelo               = newcontainer1.createNewAgent("serzedelo",                 "Agents.AgenteEstacao", new Object[] {});
            AgentController sobradelo_da_goma       = newcontainer1.createNewAgent("sobradelo_da_goma",         "Agents.AgenteEstacao", new Object[] {});
            AgentController taide                   = newcontainer1.createNewAgent("taide",                     "Agents.AgenteEstacao", new Object[] {});
            AgentController travassos               = newcontainer1.createNewAgent("travassos",                 "Agents.AgenteEstacao", new Object[] {});
            AgentController verim                   = newcontainer1.createNewAgent("verim",                     "Agents.AgenteEstacao", new Object[] {});
            AgentController vilela                  = newcontainer1.createNewAgent("vilela",                    "Agents.AgenteEstacao", new Object[] {});

            aguas_santas.start();
            ajude.start();
            brunhais.start();
            calvos.start();
            campos.start();
            covelas.start();
            esperanca.start();
            ferreiros.start();
            fonte_arcada.start();
            frades.start();
            friande.start();
            galegos.start();
            garfe.start();
            geraz_do_minho.start();
            lanhoso.start();
            louredo.start();
            monsul.start();
            moure.start();
            nossa_senhora_do_amparo.start();
            oliveira.start();
            rendufinho.start();
            santo_emiliao.start();
            sao_joao_de_rei.start();
            serzedelo.start();
            sobradelo_da_goma.start();
            taide.start();
            travassos.start();
            verim.start();
            vilela.start();

            Thread.sleep(2000);

            for(int i = 0; i < Consts.waves; i++){
                for(int j = 0; j < Consts.utilizadores; j++){
                    AgentController utilizador = newcontainer2.createNewAgent("utilizador" + "-" + i + "-" + j, "Agents.AgenteUtilizador", new Object[] {});
                    utilizador.start();
                }
                Thread.sleep(Consts.espera);
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}