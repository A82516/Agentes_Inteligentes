package Auxiliar;

public class Consts {
    // Ondas de utilizadores
    public static int waves = 5;
    // Utilizadores / onda
    public static int utilizadores = 274;
    // Tempo entre ondas
    public static int espera = 10000;
    // Multiplicador do limite
    public static int limite = 4;
    // Panico elevado
    public static int panico = 117;
    // Tempo de espera para terminar a inicializacão do Utilizador
    public static int init = 500;
    // Numero de Estacoes
    public static int numEstacoes = 29;
    // Multiplicador da velocidade
    public static int velocidade = 10;
    // Tempo do tick da viagem
    public static int tick = 1;
    // Número mínimo de respostas de estacões para o utilizador calcular o desconto
    public static int minResp = 28;
    // Influência da personalidade no calculo do desconto
    public static int personalidade = 25;
    // Distância máxima à qual um utilizador termina a viagem
    public static int proximo = 15;
    // Raio da área de proximidade
    public static int proximidade = 150;
    // Limite inferior para a Ocupacão Máxima
    public static int minimo = 5;
}
