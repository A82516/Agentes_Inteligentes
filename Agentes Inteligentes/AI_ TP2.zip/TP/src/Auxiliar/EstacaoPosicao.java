package Auxiliar;

import jade.core.AID;

import java.util.Collections;
import java.util.List;

public class EstacaoPosicao implements java.io.Serializable{
    private AID estacao;
    private Posicao pos;

    public EstacaoPosicao(AID estacao, Posicao pos) {
        super();
        this.pos = pos;
        this.estacao = estacao;
    }

    public AID getEstacao(){ return this.estacao; }

    public Posicao getPos() {
        return pos;
    }

    public double compara(EstacaoPosicao dest) {
        return Posicao.distancia(this.getPos(), dest.getPos());
    }

    public static int partition(List<EstacaoPosicao> lista, EstacaoPosicao dest, int low, int high){
        double pivot = lista.get(high).compara(dest);
        int i = (low-1); // index of smaller element
        for (int j=low; j<high; j++){
            // If current element is smaller than the pivot
            if (lista.get(j).compara(dest) < pivot){
                i++;

                // swap arr[i] and arr[j]
                Collections.swap(lista, i, j);
            }
        }
        // swap arr[i+1] and arr[high] (or pivot)
        Collections.swap(lista, i+1, high);
        return i+1;
    }


    /* The main function that implements QuickSort()
      arr[] --> Array to be sorted,
      low  --> Starting index,
      high  --> Ending index */
    public static void sort(List<EstacaoPosicao> lista, EstacaoPosicao dest, int low, int high){
        if (low < high){
            /* pi is partitioning index, arr[pi] is
              now at right place */
            int pi = partition(lista, dest, low, high);

            // Recursively sort elements before
            // partition and after partition
            EstacaoPosicao.sort(lista, dest, low, pi-1);
            EstacaoPosicao.sort(lista, dest, pi+1, high);
        }
    }
}