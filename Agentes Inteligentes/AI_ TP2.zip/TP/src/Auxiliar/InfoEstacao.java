package Auxiliar;

import jade.core.AID;

import java.io.Serializable;
import java.util.List;

public class InfoEstacao implements Serializable {
    private String nome;
    private Posicao pos;
    private int ocupacao, limiteOcupacao, incoming, perdido, excesso, reroute;
    private double panico;
    private List<AID> proximos;

    public InfoEstacao(String nome, Posicao pos, int ocupacao, int limiteOcupacao, int incoming, int perdido, int excesso, int reroute, double panico, List<AID> proximos){
        this.nome = nome;
        this.pos = pos;
        this.ocupacao = ocupacao;
        this.limiteOcupacao = limiteOcupacao;
        this.incoming = incoming;
        this.perdido = perdido;
        this.excesso = excesso;
        this.reroute = reroute;
        this.panico = panico;
        this.proximos = proximos;
    }

    public InfoEstacao replace(InfoEstacao nova){
        this.nome = nova.nome;
        this.pos = nova.pos;
        this.ocupacao = nova.ocupacao;
        this.limiteOcupacao = nova.limiteOcupacao;
        this.incoming = nova.incoming;
        this.panico = nova.panico;
        this.proximos = nova.proximos;

        return this;
    }

    public String sim(){
        return nome +
                ", Ocupação Atual: " + ocupacao +
                ", Ocupação Máxima: " + limiteOcupacao +
                ", Utilizadores perdidos: " + perdido +
                ", Excesso: " + excesso +
                ", Reroute: " + reroute + "\n";
    }

    @Override
    public String toString(){
        String r = nome +
                ", " + pos.toString() +
                ", Ocupação Atual: " + ocupacao +
                ", Ocupação Máxima: " + limiteOcupacao +
                ", À espera de " + incoming + " utilizadores" +
                ", Utilizadores perdidos: " + perdido +
                ", Excesso: " + excesso +
                ", Reroute: " + reroute +
                ", Pánico: " + panico +
                ", Proximos: " + this.proximos.size() +  " (";
        for(int i = 0; i < this.proximos.size(); i++){ r += this.proximos.get(i).getLocalName() + ", "; }
        r += ")";
        return r;
    }
}