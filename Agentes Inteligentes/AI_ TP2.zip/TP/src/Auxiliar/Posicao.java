package Auxiliar;

import static java.lang.StrictMath.sqrt;

public class Posicao implements java.io.Serializable {

    private double x,y;

    public Posicao(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public static Posicao velocidade(Posicao a, Posicao b){
        Posicao c = new Posicao(b.getX()-a.getX(), b.getY()-a.getY());
        double l = sqrt((c.getX()*c.getX()) + (c.getY() * c.getY()));
        c.x = c.x/l;
        c.y = c.y/l;

        return c;
    }
    public static double distancia(Posicao a, Posicao b){
        double x = b.getX() - a.getX();
        double y = b.getY() - a.getY();
        return sqrt((x*x) + (y*y));
    }

    public static void mais(Posicao og, Posicao vel){
        og.x = og.x + vel.x;
        og.y = og.y + vel.y;
    }

    public void vezes(double x){
        this.x = this.x * x;
        this.y = this.y * x;
    }

    public String toString() {
        return "(" + x + " , " + y + ')';
    }
}