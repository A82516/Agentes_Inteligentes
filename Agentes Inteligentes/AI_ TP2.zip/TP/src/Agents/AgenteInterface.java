package Agents;

import Auxiliar.InfoEstacao;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.UnreadableException;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

public class AgenteInterface extends Agent {
    private Map<AID, InfoEstacao> infoEstacoes;

    protected void setup() {
        // Setup
        super.setup();
        this.infoEstacoes = new TreeMap<>();
        addBehaviour(new Receiver());
    }

    protected void takeDown() {
        // Takedown
        super.takeDown();
    }

    private class Receiver extends CyclicBehaviour {

        public void action() {
            ACLMessage msg = receive();
            if (msg != null) {
                // Se nós pedirmos a info das estacões
                if (msg.getPerformative() == ACLMessage.REQUEST) {
                    // Todas estacões
                    if(msg.getContent().equals("todas")){
                        // Criar um template de estacao para procurar todas as estacões nas páginas amarelas
                        DFAgentDescription template = new DFAgentDescription();
                        ServiceDescription sd = new ServiceDescription();
                        sd.setType("estacao");
                        template.addServices(sd);

                        try {
                            // Pedir info a todas as estacões que estavam inscritas nas páginas amarelas
                            DFAgentDescription[] result = DFService.search(myAgent, template);
                            if(result.length > 0){
                                for(int i = 0; i < result.length; i++){
                                    // Pedir info
                                    ACLMessage send = new ACLMessage(ACLMessage.REQUEST);
                                    send.addReceiver(result[i].getName());
                                    send.setContent("info");
                                    myAgent.send(send);
                                }
                            }
                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    } else if(msg.getContent().equals("sim")){
                        try {
                            FileWriter wr = new FileWriter("sim.txt");
                            infoEstacoes.forEach((aid, estacao) -> {
                                try {
                                    wr.write(estacao.sim());
                                } catch (IOException e) { e.printStackTrace(); }
                            });
                            wr.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        // Se for apenas uma estacão
                        String nome = msg.getContent();

                        // Procurar a estacão
                        DFAgentDescription template = new DFAgentDescription();
                        ServiceDescription sd = new ServiceDescription();
                        sd.setName(nome);
                        template.addServices(sd);
                        try {
                            DFAgentDescription[] result = DFService.search(myAgent, template);
                            if(result.length > 0){
                                // Pedir info
                                ACLMessage send = new ACLMessage(ACLMessage.REQUEST);
                                send.addReceiver(result[0].getName());
                                send.setContent("info");
                                myAgent.send(send);
                            }
                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
                // Se for a estacão a responder com info
                else if (msg.getPerformative() == ACLMessage.INFORM){
                    try {
                        // Adicionar e dar output da info da estacão que respondeu

                        AID aid = msg.getSender();
                        InfoEstacao content = (InfoEstacao) msg.getContentObject();
                        if(infoEstacoes.containsKey(aid)){
                            infoEstacoes.get(aid).replace(content);
                        } else {
                            infoEstacoes.put(aid, content);
                        }
                        System.out.println(content.toString());
                    } catch (UnreadableException e) {
                        e.printStackTrace();
                    }
                } else {
                    System.out.println("Não Entendi " + msg.getPerformative());
                }
            } else block();
        }
    }
}
