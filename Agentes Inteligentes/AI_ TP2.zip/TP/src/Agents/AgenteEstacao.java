package Agents;

import Auxiliar.Consts;
import Auxiliar.EstacaoPosicao;
import Auxiliar.InfoEstacao;
import Auxiliar.Posicao;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import java.util.ArrayList;
import java.util.List;

public class AgenteEstacao extends Agent {
    private String nome;
    private Posicao pos;
    private int ocupacao, limiteOcupacao, incoming, perdido, excesso, reroute;
    private double panico;
    private List<AID> proximos;

    protected void setup() {
        super.setup();
        // Inicializacao da estacao
        this.nome = this.getLocalName();
        this.incoming = 0;
        this.perdido = 0;
        this.excesso = 0;
        this.reroute = 0;
        this.proximos = new ArrayList<>();
        switch (this.nome) {
            case "aguas_santas" :{
                this.limiteOcupacao = 21;
                this.pos = new Posicao(130, 330);
                break;
            }
            case "ajude" :{
                this.limiteOcupacao = 7;
                this.pos = new Posicao(240, 140);
                break;
            }
            case "brunhais" :{
                this.limiteOcupacao = 16;
                this.pos = new Posicao(810, 540);
                break;
            }
            case "calvos" :{
                this.limiteOcupacao = 24;
                this.pos = new Posicao(470, 430);
                break;
            }
            case "campos" :{
                this.limiteOcupacao = 52;
                this.pos = new Posicao(350, 800);
                break;
            }
            case "covelas" :{
                this.limiteOcupacao = 21;
                this.pos = new Posicao(60, 480);
                break;
            }
            case "esperanca" :{
                this.limiteOcupacao = 17;
                this.pos = new Posicao(900, 510);
                break;
            }
            case "ferreiros" :{
                this.limiteOcupacao = 21;
                this.pos = new Posicao(170, 470);
                break;
            }
            case "fonte_arcada" :{
                this.limiteOcupacao = 64;
                this.pos = new Posicao(510, 570);
                break;
            }
            case "frades" :{
                this.limiteOcupacao = 14;
                this.pos = new Posicao(510, 350);
                break;
            }
            case "friande" :{
                this.limiteOcupacao = 12;
                this.pos = new Posicao(370, 120);
                break;
            }
            case "galegos" :{
                this.limiteOcupacao = 27;
                this.pos = new Posicao(320, 650);
                break;
            }
            case "garfe" :{
                this.limiteOcupacao = 50;
                this.pos = new Posicao(500, 860);
                break;
            }
            case "geraz_do_minho" :{
                this.limiteOcupacao = 27;
                this.pos = new Posicao(260, 400);
                break;
            }
            case "lanhoso" :{
                this.limiteOcupacao = 36;
                this.pos = new Posicao(240, 580);
                break;
            }
            case "louredo" :{
                this.limiteOcupacao = 22;
                this.pos = new Posicao(270, 750);
                break;
            }
            case "monsul" :{
                this.limiteOcupacao = 39;
                this.pos = new Posicao(220, 300);
                break;
            }
            case "moure" :{
                this.limiteOcupacao = 12;
                this.pos = new Posicao(70, 370);
                break;
            }
            case "nossa_senhora_do_amparo" :{
                this.limiteOcupacao = 252;
                this.pos = new Posicao(400,560);
                break;
            }
            case "oliveira" :{
                this.limiteOcupacao = 20;
                this.pos = new Posicao(640, 500);
                break;
            }
            case "rendufinho" :{
                this.limiteOcupacao = 37;
                this.pos = new Posicao(410, 310);
                break;
            }
            case "santo_emiliao" :{
                this.limiteOcupacao = 46;
                this.pos = new Posicao(280, 860);
                break;
            }
            case "sao_joao_de_rei" :{
                this.limiteOcupacao = 20;
                this.pos = new Posicao(310, 260);
                break;
            }
            case "serzedelo" :{
                this.limiteOcupacao = 36;
                this.pos = new Posicao(640, 320);
                break;
            }
            case "sobradelo_da_goma" :{
                this.limiteOcupacao = 40;
                this.pos = new Posicao(860, 680);
                break;
            }
            case "taide" :{
                this.limiteOcupacao = 81;
                this.pos = new Posicao(570, 680);
                break;
            }
            case "travassos" :{
                this.limiteOcupacao = 35;
                this.pos = new Posicao(720, 570);
                break;
            }
            case "verim" :{
                this.limiteOcupacao = 18;
                this.pos = new Posicao(190, 180);
                break;
            }
            case "vilela" :{
                this.limiteOcupacao = 31;
                this.pos = new Posicao(420, 730);
                break;
            }
        }
        limiteOcupacao = limiteOcupacao/Consts.limite;
        if(limiteOcupacao < Consts.minimo) limiteOcupacao = Consts.minimo;
        this.ocupacao = limiteOcupacao;
        this.panico = 0;

        // Registo nas páginas amarelas
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(this.getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType("estacao");
        sd.setName(nome);
        dfd.addServices(sd);

        try{
            DFService.register(this, dfd);
        } catch (Exception e){ e.printStackTrace(); }

        this.addBehaviour(new Receiver());
    }

    protected void takeDown() {
        super.takeDown();
        try {
            DFService.deregister(this);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private double recalc(int ocupacao, int limiteOcupacao, int incoming){
        if(ocupacao > limiteOcupacao) return Consts.panico;
        else {
            double a = ocupacao + incoming;
            return a/limiteOcupacao;
        }
    }

    private class Receiver extends CyclicBehaviour {
        public void action() {
            panico = recalc(ocupacao, limiteOcupacao, incoming);
            ACLMessage msg = receive();
            if (msg != null) {
                if(msg.getPerformative() == ACLMessage.REQUEST){
                    // Interface a pedir info
                    if(msg.getContent().equals("info")){
                        ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                        send.addReceiver(msg.getSender());
                        InfoEstacao info = new InfoEstacao(nome, pos, ocupacao, limiteOcupacao, incoming, perdido, excesso, reroute, panico, proximos);
                        try{
                            send.setContentObject(info);
                        } catch (Exception e){ e.printStackTrace(); }
                        myAgent.send(send);
                    }
                    // Utilizador a pedir posicão
                    else if(msg.getContent().equals("pos")){
                        ACLMessage send = new ACLMessage(ACLMessage.AGREE);
                        send.addReceiver(msg.getSender());
                        EstacaoPosicao info = new EstacaoPosicao(myAgent.getAID(), pos);
                        try{
                            send.setContentObject(info);
                        } catch (Exception e){ e.printStackTrace(); }
                        myAgent.send(send);
                    }
                    // Utilizador a pedir pánico
                    else if(msg.getContent().equals("panic")){
                        ACLMessage send = new ACLMessage(ACLMessage.DISCONFIRM);
                        send.addReceiver(msg.getSender());
                        send.setContent(Double.toString(panico));
                        myAgent.send(send);
                    }
                    // Utilizador a perguntar se pode finalizar a viagem
                    else if(msg.getContent().equals("posso")){
                        if(ocupacao + incoming < limiteOcupacao){
                            ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                            send.addReceiver(msg.getSender());
                            send.setContent("podes");
                            myAgent.send(send);
                        } else {
                            ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                            send.addReceiver(msg.getSender());
                            send.setContent("nope");
                            myAgent.send(send);
                        }
                    }
                } else if(msg.getPerformative() == ACLMessage.INFORM){
                    // Utilizador a iniciar a viagem saindo desta estacão
                    if(msg.getContent().equals("bye")){
                        // Se não houverem bicicletas não pode
                        if(ocupacao == 0){
                            ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                            send.addReceiver(msg.getSender());
                            send.setContent("empty");
                            myAgent.send(send);
                            perdido++;
                        } else {
                            ocupacao--;
                        }
                    }
                    // Utilizador a informar o destino que se dirige para lá
                    else if(msg.getContent().equals("omw")){
                        incoming++;
                    }
                    // Utilizador a informar que está na área de proximidade
                    else if(msg.getContent().equals("close")){
                        proximos.add(msg.getSender());
                    }
                    // Utilizador a informar que saiu da área de proximidade
                    else if(msg.getContent().equals("far")){
                        proximos.remove(msg.getSender());
                    }
                    // Utilizador a informar o destino que chegou
                    else if(msg.getContent().equals("cheguei")){
                        incoming--;
                        ocupacao++;
                        if(ocupacao > limiteOcupacao) { excesso++; }
                    }
                    // Utilizador a informar o destino que afinal não haviam bicicletas na origem
                    else if(msg.getContent().equals("oopsies")){
                        incoming--;
                    }
                    // Utilizador a informar da mudanca de destino
                    else if(msg.getContent().equals("reroute")){
                        incoming++;
                        reroute++;
                    }
                }
            } else block();
        }
    }
}
