package Agents;

import Auxiliar.Consts;
import Auxiliar.EstacaoPosicao;
import Auxiliar.Posicao;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.core.behaviours.WakerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;

import java.util.*;

public class AgenteUtilizador extends Agent {
    private Posicao pos;
    private Posicao velocidade;
    private AID origem;
    private AID destino;
    private double distanciaTotal;
    private boolean def;
    private boolean uhoh;
    private int personalidade;
    private List<EstacaoPosicao> estacoes;
    private List<AID> proximas;
    private Map<AID, Double> panicos;

    protected void setup() {
        super.setup();
        distanciaTotal = 0;
        personalidade = new Random().nextInt(3);
        def = false;
        uhoh = false;
        estacoes = new ArrayList<>();
        proximas = new ArrayList<>();
        panicos = new TreeMap<>();

        // Escolha da origem com base na populacão da freguesia
        int origemAux = new Random().nextInt(21919);
        String freguesia;
        if(origemAux <= 417){
            freguesia = "aguas_santas";
            this.pos = new Posicao(130, 330);
        } else if(origemAux <= 556) {
            freguesia = "ajude";
            this.pos = new Posicao(240, 140);
        } else if(origemAux <= 869) {
            freguesia = "brunhais";
            this.pos = new Posicao(810, 540);
        } else if(origemAux <= 1352) {
            freguesia = "calvos";
            this.pos = new Posicao(470, 430);
        } else if(origemAux <= 2398) {
            freguesia = "campos";
            this.pos = new Posicao(350, 800);
        } else if(origemAux <= 2814) {
            freguesia = "covelas";
            this.pos = new Posicao(60, 480);
        } else if(origemAux <= 3153) {
            freguesia = "esperanca";
            this.pos = new Posicao(900, 510);
        } else if(origemAux <= 3569) {
            freguesia = "ferreiros";
            this.pos = new Posicao(170, 470);
        } else if(origemAux <= 4843) {
            freguesia = "fonte_arcada";
            this.pos = new Posicao(510, 570);
        } else if(origemAux <= 5113) {
            freguesia = "frades";
            this.pos = new Posicao(510, 350);
        } else if(origemAux <= 5354) {
            freguesia = "friande";
            this.pos = new Posicao(370, 120);
        } else if(origemAux <= 5897) {
            freguesia = "galegos";
            this.pos = new Posicao(320, 650);
        } else if(origemAux <= 6897) {
            freguesia = "garfe";
            this.pos = new Posicao(500, 860);
        } else if(origemAux <= 7443) {
            freguesia = "geraz_do_minho";
            this.pos = new Posicao(260, 400);
        } else if(origemAux <= 8163) {
            freguesia = "lanhoso";
            this.pos = new Posicao(240, 580);
        } else if(origemAux <= 8602) {
            freguesia = "louredo";
            this.pos = new Posicao(270, 750);
        } else if(origemAux <= 9372) {
            freguesia = "monsul";
            this.pos = new Posicao(220, 300);
        } else if(origemAux <= 9614) {
            freguesia = "moure";
            this.pos = new Posicao(70, 370);
        } else if(origemAux <= 14662) {
            freguesia = "nossa_senhora_do_amparo";
            this.pos = new Posicao(400, 560);
        } else if(origemAux <= 15060) {
            freguesia = "oliveira";
            this.pos = new Posicao(640, 500);
        } else if(origemAux <= 15796) {
            freguesia = "rendufinho";
            this.pos = new Posicao(410, 310);
        } else if(origemAux <= 16722) {
            freguesia = "santo_emiliao";
            this.pos = new Posicao(280, 860);
        } else if(origemAux <= 17123) {
            freguesia = "sao_joao_de_rei";
            this.pos = new Posicao(310, 260);
        } else if(origemAux <= 17842) {
            freguesia = "serzedelo";
            this.pos = new Posicao(640, 320);
        } else if(origemAux <= 18636) {
            freguesia = "sobradelo_da_goma";
            this.pos = new Posicao(860, 680);
        } else if(origemAux <= 20249) {
            freguesia = "taide";
            this.pos = new Posicao(570, 680);
        } else if(origemAux <= 20947) {
            freguesia = "travassos";
            this.pos = new Posicao(720, 570);
        } else if(origemAux <= 21303) {
            freguesia = "verim";
            this.pos = new Posicao(190, 180);
        } else {
            freguesia = "vilela";
            this.pos = new Posicao(420, 730);
        }
        // Escolha do destino com base na densidade populacional
        String freguesiaD = freguesia;
        int destinoAux;
        while(freguesia.equals(freguesiaD)){
            destinoAux = new Random().nextInt(5233);
            if(destinoAux <= 153){
                freguesiaD = "aguas_santas";
            } else if(destinoAux <= 248) {
                freguesiaD = "ajude";
            } else if(destinoAux <= 339) {
                freguesiaD = "brunhais";
            } else if(destinoAux <= 447) {
                freguesiaD = "calvos";
            } else if(destinoAux <= 680) {
                freguesiaD = "campos";
            } else if(destinoAux <= 827) {
                freguesiaD = "covelas";
            } else if(destinoAux <= 919) {
                freguesiaD = "esperanca";
            } else if(destinoAux <= 1004) {
                freguesiaD = "ferreiros";
            } else if(destinoAux <= 1214) {
                freguesiaD = "fonte_arcada";
            } else if(destinoAux <= 1280) {
                freguesiaD = "frades";
            } else if(destinoAux <= 1326) {
                freguesiaD = "friande";
            } else if(destinoAux <= 1544) {
                freguesiaD = "galegos";
            } else if(destinoAux <= 1757) {
                freguesiaD = "garfe";
            } else if(destinoAux <= 1878) {
                freguesiaD = "geraz_do_minho";
            } else if(destinoAux <= 1992) {
                freguesiaD = "lanhoso";
            } else if(destinoAux <= 2308) {
                freguesiaD = "louredo";
            } else if(destinoAux <= 2536) {
                freguesiaD = "monsul";
            } else if(destinoAux <= 2747) {
                freguesiaD = "moure";
            } else if(destinoAux <= 3645) {
                freguesiaD = "nossa_senhora_do_amparo";
            } else if(destinoAux <= 3732) {
                freguesiaD = "oliveira";
            } else if(destinoAux <= 3815) {
                freguesiaD = "rendufinho";
            } else if(destinoAux <= 4327) {
                freguesiaD = "santo_emiliao";
            } else if(destinoAux <= 4399) {
                freguesiaD = "sao_joao_de_rei";
            } else if(destinoAux <= 4467) {
                freguesiaD = "serzedelo";
            } else if(destinoAux <= 4544) {
                freguesiaD = "sobradelo_da_goma";
            } else if(destinoAux <= 4764) {
                freguesiaD = "taide";
            } else if(destinoAux <= 4958) {
                freguesiaD = "travassos";
            } else if(destinoAux <= 5084) {
                freguesiaD = "verim";
            } else {
                freguesiaD = "vilela";
            }
        }
        // Pedir as coordenadas a todas as estacoes
        DFAgentDescription template = new DFAgentDescription();
        ServiceDescription sdtmp = new ServiceDescription();
        sdtmp.setType("estacao");
        template.addServices(sdtmp);
        try {
            DFAgentDescription[] result = DFService.search(this, template);
            if(result.length > 0){
                for(int i = 0; i < result.length; i++){
                    ACLMessage send = new ACLMessage(ACLMessage.REQUEST);
                    send.addReceiver(result[i].getName());
                    send.setContent("pos");
                    this.send(send);
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        this.addBehaviour(new Receiver());
        // Tempo para dar tempo às estacoes para responder, pode ser aumentado se muitos agentes ao mesmo tempo abrandarem a simulacão
        this.addBehaviour(new Inicializacao(this, Consts.init, freguesia, freguesiaD));
    }

    protected void takeDown() {
        super.takeDown();
    }

    private class Inicializacao extends WakerBehaviour {
        private final String origemS;
        private final String destinoS;

        public Inicializacao(Agent a, long timeout, String freguesiaO, String freguesiaD){
            super(a,timeout);
            this.origemS = freguesiaO;
            this.destinoS = freguesiaD;
        }

        protected void onWake() {
            // Finalizar a inicializacão
            int destIndx = 0;
            // Pegar nas coordenadas da estacão de destino e nos AIDs de origem e destino
            for(int i = 0; i < estacoes.size(); i++){
                AID aux = estacoes.get(i).getEstacao();
                if(aux.getLocalName().equals(this.origemS)) origem = aux;
                if(aux.getLocalName().equals(this.destinoS)){
                    destino = aux;
                    velocidade = Posicao.velocidade(pos, estacoes.get(i).getPos());
                    velocidade.vezes(Consts.velocidade);
                    destIndx = i;
                }
            }

            // Ordenar as estacoes existentes com base na distância ao destino
            EstacaoPosicao.sort(estacoes, estacoes.get(destIndx), 0, estacoes.size()-1);

            // Calcular a distância da origem ao destino
            distanciaTotal = Posicao.distancia(estacoes.get(0).getPos(), pos);

            // Avisar a estacão de origem que se vai precisar de uma bicicleta
            ACLMessage sendO = new ACLMessage(ACLMessage.INFORM);
            sendO.addReceiver(origem);
            sendO.setContent("bye");
            myAgent.send(sendO);

            // Avisar a estacão de destino que se vai dirigir para lá
            ACLMessage sendD = new ACLMessage(ACLMessage.INFORM);
            sendD.addReceiver(destino);
            sendD.setContent("omw");
            myAgent.send(sendD);

            // Iniciar viagem
            myAgent.addBehaviour(new Viagem(myAgent, Consts.tick));
        }
    }

    private class Viagem extends TickerBehaviour {

        public Viagem(Agent a, long timeout){
            super(a,timeout);
        }

        protected void onTick() {
            Posicao.mais(pos, velocidade);
            if(pos.getX() > 1000 || pos.getX() < 0 || pos.getY() > 1000 || pos.getY() < 0) System.out.println("Bounds!");
            // Se ainda não está decidido onde acabar a viagem
            if(!def){
                // Se cheguei aos / passei dos três quartos
                if(Posicao.distancia(estacoes.get(0).getPos(), pos) < distanciaTotal/4){
                    // Se ainda não perguntei se posso acabar a viagem
                    if(!uhoh){
                        ACLMessage send = new ACLMessage(ACLMessage.REQUEST);
                        send.addReceiver(destino);
                        send.setContent("posso");
                        myAgent.send(send);
                    }
                    // Se tenho de arranjar outro destino
                    else {
                        // Se já há pelo menos n alternativas
                        if(panicos.size() > Consts.minResp) {
                            boolean stop = false;
                            int destIndx = 0;
                            for(int i = 1; i < estacoes.size() && !stop; i++){
                                if(panicos.containsKey(estacoes.get(i).getEstacao())){
                                    double panico = panicos.get(estacoes.get(i).getEstacao());
                                    if(panico < 1){
                                        double desconto = (1 - panico)*100;
                                        int roll = new Random().nextInt(101);
                                        // Preguicoso
                                        if(personalidade == 1) desconto += Consts.personalidade;
                                        // Sovina
                                        if(personalidade == 2) desconto -= Consts.personalidade;
                                        if(desconto < 0) desconto = 0;
                                        // aceitou o desconto
                                        if(roll < desconto){
                                            stop = true;
                                            def = true;
                                            uhoh = false;

                                            // Avisar destino original da mudanca
                                            ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                                            send.addReceiver(destino);
                                            send.setContent("oopsies");
                                            myAgent.send(send);

                                            // Alterar Destino, Velocidade
                                            destino = estacoes.get(i).getEstacao();
                                            velocidade = Posicao.velocidade(pos, estacoes.get(i).getPos());
                                            velocidade.vezes(Consts.velocidade);
                                            destIndx = i;

                                            // Avisar destino novo da mudanca
                                            ACLMessage sendN = new ACLMessage(ACLMessage.INFORM);
                                            sendN.addReceiver(estacoes.get(i).getEstacao());
                                            sendN.setContent("reroute");
                                            myAgent.send(sendN);
                                        }
                                    }
                                }
                            }
                            EstacaoPosicao.sort(estacoes, estacoes.get(destIndx), 0, estacoes.size()-1);
                        }
                    }
                }
            }
            // Se cheguei ao destino
            if(Posicao.distancia(estacoes.get(0).getPos(), pos) < Consts.proximo){
                // Dizer a todas as estacões que saiu da AP
                for(int i = 0; i < proximas.size(); i++){
                    ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                    send.addReceiver(proximas.get(i));
                    send.setContent("far");
                    myAgent.send(send);
                }
                // Avisar o destino que se chegou
                ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                send.addReceiver(destino);
                send.setContent("cheguei");
                myAgent.send(send);

                myAgent.doDelete();
            } else {
                // Atualizar áreas de proximidade
                for(int i = 0; i < estacoes.size(); i++){
                    double dist = Posicao.distancia(estacoes.get(i).getPos(), pos);
                    if(dist < Consts.proximidade){
                        // Se estiver na AP e não estava antes, informar a estacão que está próximo
                        if(!proximas.contains(estacoes.get(i).getEstacao())) {
                            proximas.add(estacoes.get(i).getEstacao());
                            ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                            send.addReceiver(estacoes.get(i).getEstacao());
                            send.setContent("close");
                            myAgent.send(send);
                        }
                    } else {
                        // Se não estiver na AP e estava antes, informar a estacão que não está próximo
                        if(proximas.contains(estacoes.get(i).getEstacao())){
                            proximas.remove(estacoes.get(i).getEstacao());
                            ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                            send.addReceiver(estacoes.get(i).getEstacao());
                            send.setContent("far");
                            myAgent.send(send);
                        }
                    }
                }
            }
        }
    }

    private class Receiver extends CyclicBehaviour {
        public void action() {
            ACLMessage msg = receive();
            if (msg != null) {
                // Para poupar chatices um AGREE é uma estacão a enviar as suas coordenadas
                if(msg.getPerformative() == ACLMessage.AGREE){
                    EstacaoPosicao pos = new EstacaoPosicao(null, null);
                    try {
                        pos = (EstacaoPosicao) msg.getContentObject();
                    } catch (Exception e) { e.printStackTrace(); }
                    estacoes.add(pos);
                }
                // Para poupar chatices um DISCONFIRM é uma estacão a enviar o seu pánico
                else if(msg.getPerformative() == ACLMessage.DISCONFIRM){
                    Double d = Double.parseDouble(msg.getContent());
                    if(panicos.containsKey(msg.getSender())){
                        panicos.replace(msg.getSender(), d);
                    } else {
                        panicos.put(msg.getSender(), d);
                    }
                }
                // Quando uma estacão diz que não tem bicicletas para iniciar a viagem
                else if(msg.getPerformative() == ACLMessage.INFORM){
                    if(msg.getContent().equals("empty")){
                        // Dizer a todas as estacões que saiu da AP
                        for(int i = 0; i < proximas.size(); i++){
                            ACLMessage send= new ACLMessage(ACLMessage.INFORM);
                            send.addReceiver(proximas.get(i));
                            send.setContent("far");
                            myAgent.send(send);
                        }
                        // Dizer ao destino que afinal não vai para lá
                        ACLMessage send = new ACLMessage(ACLMessage.INFORM);
                        send.addReceiver(destino);
                        send.setContent("oopsies");
                        myAgent.send(send);

                        myAgent.doDelete();
                    } else if(msg.getContent().equals("podes")) def = true;
                    else if (msg.getContent().equals("nope")){
                        uhoh = true;
                        DFAgentDescription template = new DFAgentDescription();
                        ServiceDescription sdtmp = new ServiceDescription();
                        sdtmp.setType("estacao");
                        template.addServices(sdtmp);
                        try {
                            DFAgentDescription[] result = DFService.search(myAgent, template);
                            if(result.length > 0){
                                for(int i = 0; i < result.length; i++){
                                    ACLMessage send = new ACLMessage(ACLMessage.REQUEST);
                                    send.addReceiver(result[i].getName());
                                    send.setContent("panic");
                                    myAgent.send(send);
                                }
                            }
                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
            } else block();
        }
    }
}
